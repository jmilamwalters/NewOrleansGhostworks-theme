import NewUserValidator from 'ghost/validators/new-user';

export default NewUserValidator.create();
