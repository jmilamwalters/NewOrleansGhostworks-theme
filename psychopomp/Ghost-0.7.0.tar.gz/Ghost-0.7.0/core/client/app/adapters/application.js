import EmbeddedRelationAdapter from 'ghost/adapters/embedded-relation-adapter';

var ApplicationAdapter = EmbeddedRelationAdapter.extend();

export default ApplicationAdapter;
