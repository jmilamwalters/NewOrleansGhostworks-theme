import Ember from 'ember';

var blogUrl = Ember.Component.extend({
    tagName: '',
    config: Ember.inject.service()
});

export default blogUrl;
