var mobileQuery = matchMedia('(max-width: 800px)');

export default mobileQuery;
