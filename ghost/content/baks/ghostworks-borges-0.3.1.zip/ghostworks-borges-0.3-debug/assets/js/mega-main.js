jQuery(document).ready(function($){
	//if you change this breakpoint in the style.css file (or _layout.scss if you use SASS), don't forget to update this value as well
	var MqL = 1170;
	//move nav element position according to window width
	moveNavigation();
	$(window).on('resize', function(){
		(!window.requestAnimationFrame) ? setTimeout(moveNavigation, 300) : window.requestAnimationFrame(moveNavigation);
	});

	//mobile - open lateral menu clicking on the menu icon
	$('.mega-nav-trigger').on('click', function(event){
		event.preventDefault();
		if( $('.mega-main-content').hasClass('nav-is-visible') ) {
			closeNav();
			$('.mega-overlay').removeClass('is-visible');
		} else {
			$(this).addClass('nav-is-visible');
			$('.mega-primary-nav').addClass('nav-is-visible');
			$('.mega-main-header').addClass('nav-is-visible');
			$('.mega-main-content').addClass('nav-is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
				$('body').addClass('overflow-hidden');
			});
			toggleSearch('close');
			$('.mega-overlay').addClass('is-visible');
		}
	});

	//open search form
	$('.mega-search-trigger').on('click', function(event){
		event.preventDefault();
		toggleSearch();
		closeNav();
	});

	//close lateral menu on mobile
	$('.mega-overlay').on('swiperight', function(){
		if($('.mega-primary-nav').hasClass('nav-is-visible')) {
			closeNav();
			$('.mega-overlay').removeClass('is-visible');
		}
	});
	$('.nav-on-left .mega-overlay').on('swipeleft', function(){
		if($('.mega-primary-nav').hasClass('nav-is-visible')) {
			closeNav();
			$('.mega-overlay').removeClass('is-visible');
		}
	});
	$('.mega-overlay').on('click', function(){
		closeNav();
		toggleSearch('close')
		$('.mega-overlay').removeClass('is-visible');
	});
	// Added by Psychopomp
	$('.mega-button-close').on('click', function(){
		closeNav();
		toggleSearch('close')
		$('.mega-overlay').removeClass('is-visible');
	});

	//prevent default clicking on direct children of .mega-primary-nav
	$('.mega-primary-nav').children('.has-children').children('a').on('click', function(event){
		event.preventDefault();
	});
	//open submenu
	$('.has-children').children('a').on('click', function(event){
		if( !checkWindowWidth() ) event.preventDefault();
		var selected = $(this);
		if( selected.next('ul').hasClass('is-hidden') ) {
			//desktop version only
			selected.addClass('selected').next('ul').removeClass('is-hidden').end().parent('.has-children').parent('ul').addClass('moves-out');
			selected.parent('.has-children').siblings('.has-children').children('ul').addClass('is-hidden').end().children('a').removeClass('selected');
			$('.mega-overlay').addClass('is-visible');
		} else {
			selected.removeClass('selected').next('ul').addClass('is-hidden').end().parent('.has-children').parent('ul').removeClass('moves-out');
			$('.mega-overlay').removeClass('is-visible');
		}
		toggleSearch('close');
	});

	//submenu items - go back link
	$('.go-back').on('click', function(){
		$(this).parent('ul').addClass('is-hidden').parent('.has-children').parent('ul').removeClass('moves-out');
	});

	function closeNav() {
		$('.mega-nav-trigger').removeClass('nav-is-visible');
		$('.mega-main-header').removeClass('nav-is-visible');
		$('.mega-primary-nav').removeClass('nav-is-visible');
		$('.has-children ul').addClass('is-hidden');
		$('.has-children a').removeClass('selected');
		$('.moves-out').removeClass('moves-out');
		$('.mega-main-content').removeClass('nav-is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function(){
			$('body').removeClass('overflow-hidden');
		});
	}

	function toggleSearch(type) {
		if(type=="close") {
			//close serach
			$('.mega-search').removeClass('is-visible');
			$('.mega-search-trigger').removeClass('search-is-visible');
		} else {
			//toggle search visibility
			$('.mega-search').toggleClass('is-visible');
			$('.mega-search-trigger').toggleClass('search-is-visible');
			if($(window).width() > MqL && $('.mega-search').hasClass('is-visible')) $('.mega-search').find('input[type="search"]').focus();
			($('.mega-search').hasClass('is-visible')) ? $('.mega-overlay').addClass('is-visible') : $('.mega-overlay').removeClass('is-visible') ;
		}
	}

	function checkWindowWidth() {
		//check window width (scrollbar included)
		var e = window,
            a = 'inner';
        if (!('innerWidth' in window )) {
            a = 'client';
            e = document.documentElement || document.body;
        }
        if ( e[ a+'Width' ] >= MqL ) {
			return true;
		} else {
			return false;
		}
	}

	function moveNavigation(){
		var navigation = $('.mega-nav');
  		var desktop = checkWindowWidth();
        if ( desktop ) {
			navigation.detach();
			navigation.insertBefore('.mega-header-buttons');
		} else {
			navigation.detach();
			navigation.insertAfter('.mega-main-content');
		}
	}
});